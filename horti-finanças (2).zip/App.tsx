
import React, { useState } from 'react';
import { Header } from './components/Header';
import { SummaryCards } from './components/SummaryCards';
import { QuickActions } from './components/QuickActions';
import { ExtractSection } from './components/ExtractSection';
import { BottomNav } from './components/BottomNav';
import { NewTransactionModal } from './components/NewTransactionModal';
import { RefreshCcw } from 'lucide-react';
import { Period } from './types';

const App: React.FC = () => {
  const [selectedPeriod, setSelectedPeriod] = useState<Period>('7d');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Exact periods as requested: 1a instead of Ano, added 6m, 9m, 2a, Todo Período
  const periods: Period[] = ['Hoje', '7d', '30d', '3m', '6m', '9m', '1a', '2a', 'Todo Período'];

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-900 pb-12 overflow-x-hidden">
      <Header />
      
      <main className="max-w-xl mx-auto animate-in fade-in duration-700">
        {/* Title and Period Selector */}
        <section className="px-4 pt-6">
          <h1 className="text-3xl font-black text-slate-800 tracking-tight leading-tight">Fluxo Financeiro</h1>
          <p className="text-sm text-slate-400 font-medium">Gestão centralizada de movimentações</p>
          
          <div className="mt-6 flex items-center gap-2">
            <div className="flex-1 bg-white p-1 rounded-2xl shadow-sm border border-slate-100 flex gap-1 overflow-x-auto no-scrollbar scroll-smooth">
              {periods.map(p => (
                <button
                  key={p}
                  onClick={() => setSelectedPeriod(p)}
                  className={`flex-none py-2.5 rounded-xl text-[11px] font-bold transition-all whitespace-nowrap px-4 ${
                    selectedPeriod === p 
                      ? 'bg-slate-900 text-white shadow-lg' 
                      : 'text-slate-400 hover:text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
            <button className="bg-white p-3.5 rounded-2xl shadow-sm border border-slate-100 text-slate-400 hover:text-emerald-600 transition-colors shrink-0">
              <RefreshCcw className="w-5 h-5" />
            </button>
          </div>
        </section>

        {/* Dashboard Sections */}
        <SummaryCards />
        
        <QuickActions />

        <div className="h-4" /> {/* Spacer */}

        {/* Main Extract Section */}
        <ExtractSection onOpenNew={() => setIsModalOpen(true)} />

      </main>

      {/* Fixed Bottom Navigation with Action Button */}
      <BottomNav onOpenNew={() => setIsModalOpen(true)} />
      
      {/* Transaction Entry Form */}
      <NewTransactionModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
    </div>
  );
};

export default App;
